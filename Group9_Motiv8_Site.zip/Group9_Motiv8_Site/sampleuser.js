var sample_user = {
        id: 1,
        name: 'Mark',
        current_group_id: [1,2,3,4,5],
        current_groups: ['OSU Biking', 'OSU Weight Lifting', 'OSU Sleeping Well', 'OSU German Language Learning', 'OSU Web Development'],
        past_goals: [{
                        group_name: 'Group Name',
                        group_goal: 'Lorem ipsum dolor sit amet, sit augue legimus scaevola ad, dicam delicatissimi ei vel. Eu has veri zril, ea eam viris tractatos efficiantur, nam wisi causae postulant eu. Cu viris euismod perpetua nam, ius munere option recteque ex. An qui eius facilisis qualisque. Ea eum quem utamur, mazim fastidii eu eum.',
                        Date_left: '3/4/19'
                },
                {
                        group_name: 'Group Name',
                        group_goal: 'Lorem ipsum dolor sit amet, sit augue legimus scaevola ad, dicam delicatissimi ei vel. Eu has veri zril, ea eam viris tractatos efficiantur, nam wisi causae postulant eu. Cu viris euismod perpetua nam, ius munere option recteque ex. An qui eius facilisis qualisque. Ea eum quem utamur, mazim fastidii eu eum.',
                        Date_left: '3/2/19'
                },
                {
                        group_name: 'Group Name',
                        group_goal: 'Lorem ipsum dolor sit amet, sit augue legimus scaevola ad, dicam delicatissimi ei vel. Eu has veri zril, ea eam viris tractatos efficiantur, nam wisi causae postulant eu. Cu viris euismod perpetua nam, ius munere option recteque ex. An qui eius facilisis qualisque. Ea eum quem utamur, mazim fastidii eu eum.',
                        Date_left: '3/1/19'
                },
                {
                        group_name: 'Group Name',
                        group_goal: 'Lorem ipsum dolor sit amet, sit augue legimus scaevola ad, dicam delicatissimi ei vel. Eu has veri zril, ea eam viris tractatos efficiantur, nam wisi causae postulant eu. Cu viris euismod perpetua nam, ius munere option recteque ex. An qui eius facilisis qualisque. Ea eum quem utamur, mazim fastidii eu eum.',
                        Date_left: '2/28/19'
                },
                {
                        group_name: 'Group Name',
                        group_goal: 'Lorem ipsum dolor sit amet, sit augue legimus scaevola ad, dicam delicatissimi ei vel. Eu has veri zril, ea eam viris tractatos efficiantur, nam wisi causae postulant eu. Cu viris euismod perpetua nam, ius munere option recteque ex. An qui eius facilisis qualisque. Ea eum quem utamur, mazim fastidii eu eum.',
                        Date_left: '2/19/19'
                },
                {
                        group_name: 'Group Name',
                        group_goal: 'Lorem ipsum dolor sit amet, sit augue legimus scaevola ad, dicam delicatissimi ei vel. Eu has veri zril, ea eam viris tractatos efficiantur, nam wisi causae postulant eu. Cu viris euismod perpetua nam, ius munere option recteque ex. An qui eius facilisis qualisque. Ea eum quem utamur, mazim fastidii eu eum.',
                        Date_left: '2/16/19'
                },
                {
                        group_name: 'Group Name',
                        group_goal: 'Lorem ipsum dolor sit amet, sit augue legimus scaevola ad, dicam delicatissimi ei vel. Eu has veri zril, ea eam viris tractatos efficiantur, nam wisi causae postulant eu. Cu viris euismod perpetua nam, ius munere option recteque ex. An qui eius facilisis qualisque. Ea eum quem utamur, mazim fastidii eu eum.',
                        Date_left: '2/12/19'
                },
                {
                        group_name: 'Group Name',
                        group_goal: 'Lorem ipsum dolor sit amet, sit augue legimus scaevola ad, dicam delicatissimi ei vel. Eu has veri zril, ea eam viris tractatos efficiantur, nam wisi causae postulant eu. Cu viris euismod perpetua nam, ius munere option recteque ex. An qui eius facilisis qualisque. Ea eum quem utamur, mazim fastidii eu eum.',
                        Date_left: '2/8/19'
                },
                {
                        group_name: 'Group Name',
                        group_goal: 'Lorem ipsum dolor sit amet, sit augue legimus scaevola ad, dicam delicatissimi ei vel. Eu has veri zril, ea eam viris tractatos efficiantur, nam wisi causae postulant eu. Cu viris euismod perpetua nam, ius munere option recteque ex. An qui eius facilisis qualisque. Ea eum quem utamur, mazim fastidii eu eum.',
                        Date_left: '2/2/19'
                }
        
        ],
        pinned_messages: [{
                        group_name: 'Group Name',
                        message: 'Lorem ipsum dolor sit amet, sit augue legimus scaevola ad, dicam delicatissimi ei vel. Eu has veri zril, ea eam viris tractatos efficiantur, nam wisi causae postulant eu. Cu viris euismod perpetua nam, ius munere option recteque ex. An qui eius facilisis qualisque. Ea eum quem utamur, mazim fastidii eu eum.',
                        Date: '3/4/19 11:25am'
                },
                {
                        group_name: 'Group Name',
                        message: 'Lorem ipsum dolor sit amet, sit augue legimus scaevola ad, dicam delicatissimi ei vel. Eu has veri zril, ea eam viris tractatos efficiantur, nam wisi causae postulant eu. Cu viris euismod perpetua nam, ius munere option recteque ex. An qui eius facilisis qualisque. Ea eum quem utamur, mazim fastidii eu eum.',
                        Date: '3/2/19 1:22pm'
                },
                {
                        group_name: 'Group Name',
                        message: 'Lorem ipsum dolor sit amet, sit augue legimus scaevola ad, dicam delicatissimi ei vel. Eu has veri zril, ea eam viris tractatos efficiantur, nam wisi causae postulant eu. Cu viris euismod perpetua nam, ius munere option recteque ex. An qui eius facilisis qualisque. Ea eum quem utamur, mazim fastidii eu eum.',
                        Date:'3/1/19 12:15pm'
                },
                {
                        group_name: 'Group Name',
                        message: 'Lorem ipsum dolor sit amet, sit augue legimus scaevola ad, dicam delicatissimi ei vel. Eu has veri zril, ea eam viris tractatos efficiantur, nam wisi causae postulant eu. Cu viris euismod perpetua nam, ius munere option recteque ex. An qui eius facilisis qualisque. Ea eum quem utamur, mazim fastidii eu eum.',
                        Date: '2/28/19 2:19pm'
                },
                {
                        group_name: 'Group Name',
                        message: 'Lorem ipsum dolor sit amet, sit augue legimus scaevola ad, dicam delicatissimi ei vel. Eu has veri zril, ea eam viris tractatos efficiantur, nam wisi causae postulant eu. Cu viris euismod perpetua nam, ius munere option recteque ex. An qui eius facilisis qualisque. Ea eum quem utamur, mazim fastidii eu eum.',
                        Date: '2/19/19 8:45am'
                },
                {
                        group_name: 'Group Name',
                        message: 'Lorem ipsum dolor sit amet, sit augue legimus scaevola ad, dicam delicatissimi ei vel. Eu has veri zril, ea eam viris tractatos efficiantur, nam wisi causae postulant eu. Cu viris euismod perpetua nam, ius munere option recteque ex. An qui eius facilisis qualisque. Ea eum quem utamur, mazim fastidii eu eum.',
                        Date: '2/16/19 7:45am'
                },
                {
                        group_name: 'Group Name',
                        message: 'Lorem ipsum dolor sit amet, sit augue legimus scaevola ad, dicam delicatissimi ei vel. Eu has veri zril, ea eam viris tractatos efficiantur, nam wisi causae postulant eu. Cu viris euismod perpetua nam, ius munere option recteque ex. An qui eius facilisis qualisque. Ea eum quem utamur, mazim fastidii eu eum.',
                        Date: '2/12/19 6:09pm'
                },
                {
                        group_name: 'Group Name',
                        message: 'Lorem ipsum dolor sit amet, sit augue legimus scaevola ad, dicam delicatissimi ei vel. Eu has veri zril, ea eam viris tractatos efficiantur, nam wisi causae postulant eu. Cu viris euismod perpetua nam, ius munere option recteque ex. An qui eius facilisis qualisque. Ea eum quem utamur, mazim fastidii eu eum.',
                        Date: '2/8/19 10:19am'
                },
                {
                        group_name: 'Group Name',
                        message: 'Lorem ipsum dolor sit amet, sit augue legimus scaevola ad, dicam delicatissimi ei vel. Eu has veri zril, ea eam viris tractatos efficiantur, nam wisi causae postulant eu. Cu viris euismod perpetua nam, ius munere option recteque ex. An qui eius facilisis qualisque. Ea eum quem utamur, mazim fastidii eu eum.',
                        Date: '2/2/19 10:51am'
                }

        ]
};

module.exports = sample_user;