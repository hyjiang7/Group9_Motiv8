module.exports = function(){
        var express = require('express');
        var router = express.Router();
     
        //get request to joinagroup
        router.get('/', function(req, res){

                var results ={};
                results.localcss = ['joinagroup.css'];
                
                res.render("joinagroup", results);
        });

       
        return router;
}();