module.exports = function(){
        var express = require('express');
        var router = express.Router();
        
        //get request to /currentgroups
        router.get('/', function(req, res){
                //a few sample groups and render on page
                var results ={};
                results.activeGroups = ["Reading", "Daily Workout", "Studying", "OSU CS"];
                results.localcss = ['currentgroups.css'];
                var sample = "Lorem ipsum dolor sit amet, sit augue legimus scaevola ad, dicam delicatissimi ei vel.Lorem ipsum dolor sit amet, sit augue legimus scaevola ad, dicam delicatissimi ei vel.";
                results.goalName = [sample, sample, sample, sample];

                results.groupMembers = [];

                results.groupMembers[0] = {};
                results.groupMembers[0].name = "Sam";
                results.groupMembers[0].progress = 2;
                results.groupMembers[0].progressPercent = 10;

                results.groupMembers[1] = {};
                results.groupMembers[1].name = "Casey";
                results.groupMembers[1].progress = 8;
                results.groupMembers[1].progressPercent = 40;

                results.groupMembers[2] = {};
                results.groupMembers[2].name = "Charlie";
                results.groupMembers[2].progress = 10;
                results.groupMembers[2].progressPercent = 50;

                results.groupMembers[3] = {};
                results.groupMembers[3].name = "Mark";
                results.groupMembers[3].progress = 12;
                results.groupMembers[3].progressPercent = 60;

                results.groupMembers[4] = {};
                results.groupMembers[4].name = "Robert";
                results.groupMembers[4].progress = 10;
                results.groupMembers[4].progressPercent = 50;

                results.groupMembers[5] = {};
                results.groupMembers[5].name = "Susan";
                results.groupMembers[5].progress = 2;
                results.groupMembers[5].progressPercent = 10;


                res.render("currentgroups", results);
        });

        return router;
}();