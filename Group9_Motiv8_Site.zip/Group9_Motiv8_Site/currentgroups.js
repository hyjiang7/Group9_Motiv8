module.exports = function(){
        var express = require('express');
        var router = express.Router();
        var groups = require('./groups.js');
        var sample_user = require('./sampleuser.js');
        
       // groups = groups.groups;
        //get request to /currentgroups
        router.get('/', function(req, res){
                //a few sample groups and render on page
                var results ={};
                results.localcss = ['currentgroups.css'];
                results.activeGroups = [];
                results.groupMembers = [];

                //Get all groups for user 
                for(var i = 0; i < sample_user.current_groups.length; i++){
                        
                        results.activeGroups[i] = sample_user.current_groups[i];
                }
                /***************************************************
                 * Use first group as example for Goal Progress
                 ****************************************************/
                //get weekly goal
                results.weeklyGoal = groups[0].group_all_goals[0];
                //get totalMembers
                results.totalMembers = groups[0].members.length;

                //get user's info (placed first in arrays)
                results.self = {name: groups[0].members[0],
                                progress: groups[0].progress[0],
                                progressPercent: ((groups[0].progress[0])/20)* 100,
                                unit: groups[0].unit
                };
             
                //get info for first group 
                for(var i = 1; i < groups[0].members.length; i++){
                        results.groupMembers[i] = {};
                        results.groupMembers[i].name = groups[0].members[i];
                        results.groupMembers[i].progress = groups[0].progress[i];
                        results.groupMembers[i].progressPercent = ((groups[0].progress[i])/20)* 100;
                        results.groupMembers[i].unit = groups[0].unit;
                }
               
                res.render("currentgroups", results);
        });

        return router;
}();