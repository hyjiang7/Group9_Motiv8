//express for routing
var express = require('express');
var app = express();

//handlebars for html manipulation
var handlebars = require('express-handlebars').create({defaultLayout:'main'});
app.engine('handlebars', handlebars.engine);

//get static files from public folder
app.use('/static', express.static('public'));
app.set('view engine', 'handlebars');
app.use('/', express.static('public'));

//route to appropriate files
app.use('/currentgroups', require('./currentgroups.js'));
app.use('/joinagroup', require('./joinagroup.js'));
app.use('/pastgoals', require('./pastgoals.js'));
app.use('/pinnedmessages', require('./pinnedmessages'));


//listen on local port 3001
app.listen(3001, function () {
        console.log('Express started on http://localhost:3001');
});