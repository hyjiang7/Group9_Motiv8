module.exports = function(){
        var express = require('express');
        var router = express.Router();
        
        //get request to pastgoals
        router.get('/', function(req, res){

                var results ={};
                results.localcss = ['pastgoals.css'];
                //sample goal for group
                var sample = "Lorem ipsum dolor sit amet, sit augue legimus scaevola ad, dicam delicatissimi ei vel. Eu has veri zril, ea eam viris tractatos efficiantur, nam wisi causae postulant eu. Cu viris euismod perpetua nam, ius munere option recteque ex. An qui eius facilisis qualisque. Ea eum quem utamur, mazim fastidii eu eum.";
                //pastgoals is an array objects with 2 keys: goal and date
                results.pastgoals = [];
                for(var i = 0; i < 9; i++){
                        results.pastgoals[i] = {};
                        results.pastgoals[i].goal = sample;
                        results.pastgoals[i].date = "12/15/18"; //sample date (won't be same date with real data)

                }

                res.render("pastgoals", results);
        });

       
        return router;
}();