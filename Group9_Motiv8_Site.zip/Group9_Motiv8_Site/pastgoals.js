module.exports = function(){
        var express = require('express');
        var router = express.Router();
        var sample_user = require('./sampleuser.js');

        //get request to pastgoals
        router.get('/', function(req, res){

                var results ={};
                results.localcss = ['pastgoals.css'];

                //past goals from sample user
                //pastgoals is an array objects with 3 keys: name, goal, date
                results.pastgoals = [];
                for(var i = 0; i < sample_user.past_goals.length; i++){
                        results.pastgoals[i] = {};
                        results.pastgoals[i].name = sample_user.past_goals[i].group_name;
                        results.pastgoals[i].goal = sample_user.past_goals[i].group_goal;
                        results.pastgoals[i].date = sample_user.past_goals[i].Date_left;

                }

                res.render("pastgoals", results);
        });

       
        return router;
}();