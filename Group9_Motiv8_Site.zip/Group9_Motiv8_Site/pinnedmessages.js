module.exports = function(){
        var express = require('express');
        var router = express.Router();
        
        //get request to pinnedmessages
        router.get('/', function(req, res){
                var results ={};
                results.localcss = ['pinnedmessages.css'];
                var sample = "Lorem ipsum dolor sit amet, sit augue legimus scaevola ad, dicam delicatissimi ei vel. Eu has veri zril, ea eam viris tractatos efficiantur, nam wisi causae postulant eu. Cu viris euismod perpetua nam, ius munere option recteque ex. An qui eius facilisis qualisque. Ea eum quem utamur, mazim fastidii eu eum.";
                //pinnedmessages is an array of objects with 2 keys: message, time
                results.pinnedmessages = [];
                for(var i = 0; i < 6; i++){
                        results.pinnedmessages[i] = {};
                        results.pinnedmessages[i].message = sample;
                        results.pinnedmessages[i].time = "12/15/19 11:25pm"     //sample date (won't be same date with real data)
                }
                res.render("pinnedmessages", results);
        });

       
        return router;
}();