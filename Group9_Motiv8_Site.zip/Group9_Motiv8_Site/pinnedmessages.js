module.exports = function(){
        var express = require('express');
        var router = express.Router();
        var sample_user = require('./sampleuser.js');

        //get request to pinnedmessages
        router.get('/', function(req, res){
                var results ={};
                results.localcss = ['pinnedmessages.css'];
                
                //pinnedmessages is an array of objects with 2 keys: message, time
                results.pinnedmessages = [];
                for(var i = 0; i < sample_user.pinned_messages.length; i++){
                        results.pinnedmessages[i] = {};
                        results.pinnedmessages[i].name = sample_user.pinned_messages[i].group_name;
                        results.pinnedmessages[i].message = sample_user.pinned_messages[i].message;
                        results.pinnedmessages[i].time = sample_user.pinned_messages[i].Date;

                }


                res.render("pinnedmessages", results);
        });

       
        return router;
}();